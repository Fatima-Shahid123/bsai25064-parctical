using UnityEngine;
using UnityEngine.InputSystem; // Required for Unity 6 New Input System

public class GlassRodController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;

    [Header("Rotation Settings")]
    public float rotationRadius = 0.5f;
    public float rotationSpeed = 2f;

    private float rotationTimer = 0f;
    private Quaternion originalRotation;

    void Start()
    {
        originalRotation = transform.rotation;
    }

    void Update()
    {
        HandleMovement();
        HandleRotation();
    }

    void HandleMovement()
    {
        float horizontal = 0f;
        float vertical = 0f;

        // Read Arrow Keys / WASD inputs directly from the New Input System keyboard layout
        if (Keyboard.current != null)
        {
            if (Keyboard.current.leftArrowKey.isPressed || Keyboard.current.aKey.isPressed) horizontal = -1f;
            if (Keyboard.current.rightArrowKey.isPressed || Keyboard.current.dKey.isPressed) horizontal = 1f;
            if (Keyboard.current.upArrowKey.isPressed || Keyboard.current.wKey.isPressed) vertical = 1f;
            if (Keyboard.current.downArrowKey.isPressed || Keyboard.current.sKey.isPressed) vertical = -1f;
        }

        Vector3 movement = new Vector3(horizontal, vertical, 0f) * moveSpeed * Time.deltaTime;
        transform.Translate(movement, Space.World);
    }

    void HandleRotation()
    {
        // Check if the 'O' key is held down
        if (Keyboard.current != null && Keyboard.current.oKey.isPressed)
        {
            rotationTimer += Time.deltaTime * rotationSpeed;

            float tiltX = Mathf.Sin(rotationTimer) * rotationRadius;
            float tiltZ = Mathf.Cos(rotationTimer) * rotationRadius;

            // Apply a circular path offset around the initial rotation baseline
            transform.rotation = originalRotation * Quaternion.Euler(tiltX * 50f, 0f, tiltZ * 50f);
        }
        else
        {
            // Smoothly snap back to original straight position when released
            rotationTimer = 0f;
            transform.rotation = Quaternion.Slerp(transform.rotation, originalRotation, Time.deltaTime * 5f);
        }
    }
}
