using UnityEngine;
using UnityEngine.InputSystem;

public class SimpleCameraController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float lookSpeed = 0.1f;

    private Vector2 rotation = Vector2.zero;

    void Start()
    {
        // FIX: The cursor lock and hide lines have been completely removed from here!
        rotation.y = transform.localRotation.eulerAngles.x;
        rotation.x = transform.localRotation.eulerAngles.y;
    }

    void Update()
    {
        // 1. MOUSE LOOK: Rotate camera ONLY if right mouse button is held down (standard Unity style)
        if (Mouse.current != null && Mouse.current.rightButton.isPressed)
        {
            Vector2 mouseDelta = Mouse.current.delta.ReadValue() * lookSpeed;

            rotation.x += mouseDelta.x;
            rotation.y -= mouseDelta.y;
            rotation.y = Mathf.Clamp(rotation.y, -60f, 60f);

            transform.localRotation = Quaternion.Euler(rotation.y, rotation.x, 0);
        }

        // 2. KEYBOARD MOVEMENT: Move using Arrow Keys or I/K/J/L (Bypasses W/S)
        if (Keyboard.current != null)
        {
            Vector3 moveDirection = Vector3.zero;

            if (Keyboard.current.upArrowKey.isPressed || Keyboard.current.iKey.isPressed)
                moveDirection += transform.forward;
            if (Keyboard.current.downArrowKey.isPressed || Keyboard.current.kKey.isPressed)
                moveDirection -= transform.forward;
            if (Keyboard.current.leftArrowKey.isPressed || Keyboard.current.jKey.isPressed)
                moveDirection -= transform.right;
            if (Keyboard.current.rightArrowKey.isPressed || Keyboard.current.lKey.isPressed)
                moveDirection += transform.right;

            transform.position += moveDirection.normalized * moveSpeed * Time.deltaTime;
        }
    }
}
