////using UnityEngine;
////using UnityEngine.InputSystem;

////public class TestTube : MonoBehaviour
////{
////    [Header("Pickup Settings")]
////    public float holdDistance = 3.5f;
////    public float moveSpeed = 12f;
////    public float rotationSpeed = 120f;

////    [Header("Hand Size Adjuster")]
////    public Vector3 heldScaleSize = new Vector3(0.15f, 0.45f, 0.15f);

////    [Header("Hand Position Offset")]
////    public float handRightOffset = 0.8f;
////    public float handDownOffset = -0.6f;

////    [Header("Up/Down Movement Settings")]
////    public float verticalSpeed = 3f;      // How fast the tube moves up/down
////    public float maxUpOffset = 1f;       // Maximum height limit
////    public float maxDownOffset = -1.5f;   // Minimum height limit

////    [Header("Pour Settings")]
////    [Range(45f, 135f)] public float pourAngleThreshold = 75f;
////    public Transform mouthPosition;
////    public ParticleSystem liquidStream;

////    private Camera mainCam;
////    private bool isHeld = false;
////    private bool isPouring = false;
////    private Quaternion originalRotation;
////    private Vector3 originalScale;
////    private Transform currentRackSlot = null;
////    private float currentVerticalOffset = 0f; // Tracks dynamic vertical movement

////    void Start()
////    {
////        mainCam = Camera.main;
////        originalRotation = transform.rotation;
////        originalScale = transform.localScale;
////    }

////    void Update()
////    {
////        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
////        {
////            if (!isHeld)
////            {
////                Vector2 mousePos = Mouse.current.position.ReadValue();
////                Ray ray = mainCam.ScreenPointToRay(mousePos);
////                if (Physics.Raycast(ray, out RaycastHit hit))
////                {
////                    if (hit.transform == this.transform || hit.transform.parent == this.transform)
////                    {
////                        isHeld = true;
////                        currentVerticalOffset = 0f; // Reset height offset on pickup
////                        if (currentRackSlot != null) currentRackSlot = null;
////                    }
////                }
////            }
////            else
////            {
////                isHeld = false;
////                isPouring = false;
////                transform.localScale = originalScale;
////                if (liquidStream != null && liquidStream.isPlaying)
////                {
////                    liquidStream.Stop();
////                }
////            }
////        }

////        if (isHeld)
////        {
////            // Smoothly shrink scale down to fit the viewport frame perfectly
////            transform.localScale = Vector3.Lerp(transform.localScale, heldScaleSize, Time.deltaTime * moveSpeed);

////            // Check Keyboard Input for Up/Down Movement (W/S or Up/Down arrows) using New Input System
////            if (Keyboard.current != null)
////            {
////                // Move Up
////                if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
////                {
////                    currentVerticalOffset += verticalSpeed * Time.deltaTime;
////                }
////                // Move Down
////                if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
////                {
////                    currentVerticalOffset -= verticalSpeed * Time.deltaTime;
////                }

////                // Clamp limits so it doesn't fly off the screen completely
////                currentVerticalOffset = Mathf.Clamp(currentVerticalOffset, maxDownOffset, maxUpOffset);
////            }

////            // Follow position in front of camera lens with offsets and dynamic vertical height adjustment
////            Vector3 centerHoldPos = mainCam.transform.position + mainCam.transform.forward * holdDistance;
////            Vector3 rightOffset = mainCam.transform.right * handRightOffset;

////            // Add our currentVerticalOffset to the base down offset calculation
////            Vector3 downOffset = mainCam.transform.up * (handDownOffset + currentVerticalOffset);
////            Vector3 targetPosition = centerHoldPos + rightOffset + downOffset;

////            transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * moveSpeed);

////            // Check Keyboard Rotation (Q/E)
////            if (Keyboard.current != null)
////            {
////                if (Keyboard.current.qKey.isPressed)
////                {
////                    transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
////                }
////                if (Keyboard.current.eKey.isPressed)
////                {
////                    transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);
////                }
////            }

////            float angle = Vector3.Angle(transform.up, Vector3.up);
////            if (angle >= pourAngleThreshold)
////            {
////                if (!isPouring)
////                {
////                    isPouring = true;
////                    if (liquidStream != null && !liquidStream.isPlaying) liquidStream.Play();
////                }
////            }
////            else
////            {
////                if (isPouring)
////                {
////                    isPouring = false;
////                    if (liquidStream != null && liquidStream.isPlaying) liquidStream.Stop();
////                }
////            }
////        }
////    }

////    private void OnTriggerEnter(Collider other)
////    {
////        if (!isHeld && other.CompareTag("RackSlot"))
////        {
////            currentRackSlot = other.transform;
////            transform.position = currentRackSlot.position;
////            transform.rotation = originalRotation;
////            transform.localScale = originalScale;
////        }
////    }
////}

//using UnityEngine;
//using UnityEngine.InputSystem;

//public class TestTube : MonoBehaviour
//{
//    [Header("Pickup Settings")]
//    public float holdDistance = 3.5f;
//    public float moveSpeed = 12f;
//    public float rotationSpeed = 120f;

//    [Header("Hand Size Adjuster")]
//    public Vector3 heldScaleSize = new Vector3(0.15f, 0.45f, 0.15f);

//    [Header("Hand Position Offset")]
//    public float handRightOffset = 0.8f;
//    public float handDownOffset = -0.6f;

//    [Header("Up/Down Movement Settings")]
//    public float verticalSpeed = 3f;
//    public float maxUpOffset = 1f;
//    public float maxDownOffset = -1.5f;

//    [Header("Liquid State")]
//    public bool hasLiquid = true;
//    [Range(0f, 1f)] public float liquidAmount = 1f; // 1 = Full, 0 = Empty
//    public Color currentLiquidColor = Color.blue;
//    public Renderer liquidInternalRenderer; // Drag your inner cylinder mesh here

//    [Header("Direct Pour Settings")]
//    [Range(45f, 135f)] public float pourAngleThreshold = 75f;
//    public float transferSpeed = 0.3f; // How fast liquid drops out per second
//    public float pourRadiusLimit = 2.5f; // Max proximity distance required to pour

//    private Camera mainCam;
//    private bool isHeld = false;
//    private Quaternion originalRotation;
//    private Vector3 originalScale;
//    private Vector3 originalPosition;
//    private float currentVerticalOffset = 0f;

//    private Vector3 initialLiquidScale;
//    private float initialLiquidYPos;

//    void Start()
//    {
//        mainCam = Camera.main;
//        originalRotation = transform.rotation;
//        originalScale = transform.localScale;
//        originalPosition = transform.position;

//        if (liquidInternalRenderer != null)
//        {
//            initialLiquidScale = liquidInternalRenderer.transform.localScale;
//            initialLiquidYPos = liquidInternalRenderer.transform.localPosition.y;
//        }

//        UpdateVisualLiquid();
//    }

//    void Update()
//    {
//        HandleInput();

//        if (isHeld)
//        {
//            HandleMovementAndRotation();
//            CheckProximityPouring();
//        }

//        UpdateVisualLiquid();
//    }

//    void HandleInput()
//    {
//        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
//        {
//            if (!isHeld)
//            {
//                Vector2 mousePos = Mouse.current.position.ReadValue();
//                Ray ray = mainCam.ScreenPointToRay(mousePos);
//                if (Physics.Raycast(ray, out RaycastHit hit))
//                {
//                    if (hit.transform == this.transform || hit.transform.parent == this.transform)
//                    {
//                        isHeld = true;
//                        currentVerticalOffset = 0f;
//                    }
//                }
//            }
//            else
//            {
//                isHeld = false;
//                transform.localScale = originalScale;
//                transform.position = originalPosition;
//                transform.rotation = originalRotation;
//            }
//        }
//    }

//    void HandleMovementAndRotation()
//    {
//        transform.localScale = Vector3.Lerp(transform.localScale, heldScaleSize, Time.deltaTime * moveSpeed);

//        if (Keyboard.current != null)
//        {
//            if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
//                currentVerticalOffset += verticalSpeed * Time.deltaTime;
//            if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
//                currentVerticalOffset -= verticalSpeed * Time.deltaTime;

//            currentVerticalOffset = Mathf.Clamp(currentVerticalOffset, maxDownOffset, maxUpOffset);

//            if (Keyboard.current.qKey.isPressed)
//                transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
//            if (Keyboard.current.eKey.isPressed)
//                transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);
//        }

//        Vector3 centerHoldPos = mainCam.transform.position + mainCam.transform.forward * holdDistance;
//        Vector3 rightOffset = mainCam.transform.right * handRightOffset;
//        Vector3 downOffset = mainCam.transform.up * (handDownOffset + currentVerticalOffset);

//        transform.position = Vector3.Lerp(transform.position, centerHoldPos + rightOffset + downOffset, Time.deltaTime * moveSpeed);
//    }

//    void CheckProximityPouring()
//    {
//        if (!hasLiquid || liquidAmount <= 0) return;

//        float currentAngle = Vector3.Angle(transform.up, Vector3.up);
//        if (currentAngle >= pourAngleThreshold)
//        {
//            // Fully updated and error-free search system for Unity 6 [1]
//            TestTube[] targets = FindObjectsByType<TestTube>();

//            foreach (TestTube targetTube in targets)
//            {
//                if (targetTube == this) continue;

//                float distance = Vector3.Distance(transform.position, targetTube.transform.position);
//                if (distance <= pourRadiusLimit)
//                {
//                    float frameTransfer = transferSpeed * Time.deltaTime;
//                    if (frameTransfer > liquidAmount) frameTransfer = liquidAmount;

//                    liquidAmount -= frameTransfer;
//                    targetTube.ReceiveFluidStream(currentLiquidColor, frameTransfer);
//                    break;
//                }
//            }
//        }
//    }

//    public void ReceiveFluidStream(Color sourceColor, float incomingAmount)
//    {
//        if (!hasLiquid || liquidAmount <= 0)
//        {
//            hasLiquid = true;
//            liquidAmount = 0f;
//            currentLiquidColor = sourceColor;
//        }
//        else
//        {
//            currentLiquidColor = Color.Lerp(currentLiquidColor, sourceColor, 0.05f);
//        }

//        liquidAmount += incomingAmount;
//        liquidAmount = Mathf.Clamp01(liquidAmount);
//    }

//    void UpdateVisualLiquid()
//    {
//        if (liquidInternalRenderer != null)
//        {
//            if (liquidAmount <= 0 || !hasLiquid)
//            {
//                liquidInternalRenderer.enabled = false;
//                hasLiquid = false;
//                return;
//            }

//            liquidInternalRenderer.enabled = true;
//            liquidInternalRenderer.material.color = currentLiquidColor;

//            Vector3 targetScale = initialLiquidScale;
//            targetScale.y = initialLiquidScale.y * liquidAmount;
//            liquidInternalRenderer.transform.localScale = targetScale;

//            float heightDifference = initialLiquidScale.y * (1f - liquidAmount);
//            Vector3 targetPos = liquidInternalRenderer.transform.localPosition;
//            targetPos.y = initialLiquidYPos - heightDifference;
//            liquidInternalRenderer.transform.localPosition = targetPos;
//        }
//    }
//}

//using UnityEngine;
//using UnityEngine.InputSystem;

//public class TestTube : MonoBehaviour
//{
//    [Header("Pickup Settings")]
//    public float holdDistance = 2.5f; // Shortened to bring the tube closer to your face
//    public float moveSpeed = 12f;
//    public float rotationSpeed = 120f;

//    [Header("Hand Size Adjuster")]
//    public Vector3 heldScaleSize = new Vector3(0.15f, 0.45f, 0.15f);

//    [Header("Hand Position Offset")]
//    public float handRightOffset = 0.8f;
//    public float handDownOffset = -0.6f;

//    [Header("Up/Down Movement Settings")]
//    public float verticalSpeed = 3f;
//    public float maxUpOffset = 1f;
//    public float maxDownOffset = -1.5f;

//    [Header("Liquid State")]
//    public bool hasLiquid = true;
//    [Range(0f, 1f)] public float liquidAmount = 1f; // 1 = Full, 0 = Empty
//    public Color currentLiquidColor = Color.blue;
//    public Renderer liquidInternalRenderer; // Drag your inner cylinder mesh here

//    [Header("Direct Pour Settings")]
//    [Range(45f, 135f)] public float pourAngleThreshold = 75f;
//    public float transferSpeed = 0.3f; // How fast liquid drops out per second
//    public float pourRadiusLimit = 5.0f; // INCREASED: Easier to pour from further away!

//    private Camera mainCam;
//    private bool isHeld = false;
//    private Quaternion originalRotation;
//    private Vector3 originalScale;
//    private Vector3 originalPosition;
//    private float currentVerticalOffset = 0f;

//    private Vector3 initialLiquidScale;
//    private float initialLiquidYPos;

//    void Start()
//    {
//        mainCam = Camera.main;
//        originalRotation = transform.rotation;
//        originalScale = transform.localScale;
//        originalPosition = transform.position;

//        if (liquidInternalRenderer != null)
//        {
//            initialLiquidScale = liquidInternalRenderer.transform.localScale;
//            initialLiquidYPos = liquidInternalRenderer.transform.localPosition.y;
//        }

//        UpdateVisualLiquid();
//    }

//    void Update()
//    {
//        HandleInput();

//        if (isHeld)
//        {
//            HandleMovementAndRotation();
//            CheckProximityPouring();
//        }

//        UpdateVisualLiquid();
//    }

//    void HandleInput()
//    {
//        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
//        {
//            if (!isHeld)
//            {
//                Vector2 mousePos = Mouse.current.position.ReadValue();
//                Ray ray = mainCam.ScreenPointToRay(mousePos);
//                if (Physics.Raycast(ray, out RaycastHit hit))
//                {
//                    if (hit.transform == this.transform || hit.transform.parent == this.transform)
//                    {
//                        isHeld = true;
//                        currentVerticalOffset = 0f;
//                    }
//                }
//            }
//            else
//            {
//                isHeld = false;
//                transform.localScale = originalScale;
//                transform.position = originalPosition;
//                transform.rotation = originalRotation;
//            }
//        }
//    }

//    void HandleMovementAndRotation()
//    {
//        transform.localScale = Vector3.Lerp(transform.localScale, heldScaleSize, Time.deltaTime * moveSpeed);

//        if (Keyboard.current != null)
//        {
//            if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
//                currentVerticalOffset += verticalSpeed * Time.deltaTime;
//            if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
//                currentVerticalOffset -= verticalSpeed * Time.deltaTime;

//            currentVerticalOffset = Mathf.Clamp(currentVerticalOffset, maxDownOffset, maxUpOffset);

//            if (Keyboard.current.qKey.isPressed)
//                transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
//            if (Keyboard.current.eKey.isPressed)
//                transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);
//        }

//        Vector3 centerHoldPos = mainCam.transform.position + mainCam.transform.forward * holdDistance;
//        Vector3 rightOffset = mainCam.transform.right * handRightOffset;
//        Vector3 downOffset = mainCam.transform.up * (handDownOffset + currentVerticalOffset);

//        transform.position = Vector3.Lerp(transform.position, centerHoldPos + rightOffset + downOffset, Time.deltaTime * moveSpeed);
//    }

//    void CheckProximityPouring()
//    {
//        if (!hasLiquid || liquidAmount <= 0) return;

//        float currentAngle = Vector3.Angle(transform.up, Vector3.up);
//        if (currentAngle >= pourAngleThreshold)
//        {
//            TestTube[] targets = FindObjectsByType<TestTube>();

//            foreach (TestTube targetTube in targets)
//            {
//                if (targetTube == this) continue;

//                float distance = Vector3.Distance(transform.position, targetTube.transform.position);
//                if (distance <= pourRadiusLimit)
//                {
//                    float frameTransfer = transferSpeed * Time.deltaTime;
//                    if (frameTransfer > liquidAmount) frameTransfer = liquidAmount;

//                    liquidAmount -= frameTransfer;
//                    targetTube.ReceiveFluidStream(currentLiquidColor, frameTransfer);
//                    break;
//                }
//            }
//        }
//    }

//    public void ReceiveFluidStream(Color sourceColor, float incomingAmount)
//    {
//        if (!hasLiquid || liquidAmount <= 0)
//        {
//            hasLiquid = true;
//            liquidAmount = 0f;
//            currentLiquidColor = sourceColor;
//        }
//        else
//        {
//            currentLiquidColor = Color.Lerp(currentLiquidColor, sourceColor, 0.05f);
//        }

//        liquidAmount += incomingAmount;
//        liquidAmount = Mathf.Clamp01(liquidAmount);
//    }

//    void UpdateVisualLiquid()
//    {
//        if (liquidInternalRenderer != null)
//        {
//            if (liquidAmount <= 0 || !hasLiquid)
//            {
//                liquidInternalRenderer.enabled = false;
//                hasLiquid = false;
//                return;
//            }

//            liquidInternalRenderer.enabled = true;
//            liquidInternalRenderer.material.color = currentLiquidColor;

//            Vector3 targetScale = initialLiquidScale;
//            targetScale.y = initialLiquidScale.y * liquidAmount;
//            liquidInternalRenderer.transform.localScale = targetScale;

//            float heightDifference = initialLiquidScale.y * (1f - liquidAmount);
//            Vector3 targetPos = liquidInternalRenderer.transform.localPosition;
//            targetPos.y = initialLiquidYPos - heightDifference;
//            liquidInternalRenderer.transform.localPosition = targetPos;
//        }
//    }
//}


using UnityEngine;
using UnityEngine.InputSystem;

public class TestTube : MonoBehaviour
{
    [Header("Pickup Settings")]
    public float holdDistance = 2.5f;
    public float moveSpeed = 12f;
    public float rotationSpeed = 120f;

    [Header("Hand Size Adjuster")]
    public Vector3 heldScaleSize = new Vector3(0.15f, 0.45f, 0.15f);

    [Header("Hand Position Offset")]
    public float handRightOffset = 0.8f;
    public float handDownOffset = -0.6f;

    [Header("Up/Down Movement Settings")]
    public float verticalSpeed = 3f;
    public float maxUpOffset = 1f;
    public float maxDownOffset = -1.5f;

    [Header("Left/Right Movement Settings")]
    public float horizontalSpeed = 3f;
    public float maxLeftOffset = -1.5f;
    public float maxRightOffset = 1.5f;

    [Header("Liquid State")]
    public bool hasLiquid = true;
    [Range(0f, 1f)]
    public float liquidAmount = 1f;
    public Color currentLiquidColor = Color.blue;
    public Renderer liquidInternalRenderer;

    [Header("Direct Pour Settings")]
    [Range(45f, 135f)]
    public float pourAngleThreshold = 75f;
    public float transferSpeed = 0.3f;
    public float pourRadiusLimit = 5.0f;

    private Camera mainCam;
    private bool isHeld = false;
    private Quaternion originalRotation;
    private Vector3 originalScale;
    private Vector3 originalPosition;

    private float currentVerticalOffset = 0f;
    private float currentHorizontalOffset = 0f; // New tracker for left/right

    private Vector3 initialLiquidScale;
    private float initialLiquidYPos;

    void Start()
    {
        mainCam = Camera.main;
        originalRotation = transform.rotation;
        originalScale = transform.localScale;
        originalPosition = transform.position;

        if (liquidInternalRenderer != null)
        {
            initialLiquidScale = liquidInternalRenderer.transform.localScale;
            initialLiquidYPos = liquidInternalRenderer.transform.localPosition.y;
        }
        UpdateVisualLiquid();
    }

    void Update()
    {
        HandleInput();
        if (isHeld)
        {
            HandleMovementAndRotation();
            CheckProximityPouring();
        }
        UpdateVisualLiquid();
    }

    void HandleInput()
    {
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            if (!isHeld)
            {
                Vector2 mousePos = Mouse.current.position.ReadValue();
                Ray ray = mainCam.ScreenPointToRay(mousePos);
                if (Physics.Raycast(ray, out RaycastHit hit))
                {
                    if (hit.transform == this.transform || hit.transform.parent == this.transform)
                    {
                        isHeld = true;
                        currentVerticalOffset = 0f;
                        currentHorizontalOffset = 0f; // Reset on pickup
                    }
                }
            }
            else
            {
                isHeld = false;
                transform.localScale = originalScale;
                transform.position = originalPosition;
                transform.rotation = originalRotation;
            }
        }
    }

    void HandleMovementAndRotation()
    {
        transform.localScale = Vector3.Lerp(transform.localScale, heldScaleSize, Time.deltaTime * moveSpeed);

        if (Keyboard.current != null)
        {
            // Up / Down Input
            if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
                currentVerticalOffset += verticalSpeed * Time.deltaTime;
            if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
                currentVerticalOffset -= verticalSpeed * Time.deltaTime;
            currentVerticalOffset = Mathf.Clamp(currentVerticalOffset, maxDownOffset, maxUpOffset);

            // Left / Right Input
            if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
                currentHorizontalOffset += horizontalSpeed * Time.deltaTime;
            if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
                currentHorizontalOffset -= horizontalSpeed * Time.deltaTime;
            currentHorizontalOffset = Mathf.Clamp(currentHorizontalOffset, maxLeftOffset, maxRightOffset);

            // Rotation Input
            if (Keyboard.current.qKey.isPressed)
                transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
            if (Keyboard.current.eKey.isPressed)
                transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);
        }

        // Calculate world space offsets relative to where the camera is looking
        Vector3 centerHoldPos = mainCam.transform.position + mainCam.transform.forward * holdDistance;
        Vector3 rightOffset = mainCam.transform.right * (handRightOffset + currentHorizontalOffset);
        Vector3 downOffset = mainCam.transform.up * (handDownOffset + currentVerticalOffset);

        // Smoothly interpolate to the final target position
        transform.position = Vector3.Lerp(transform.position, centerHoldPos + rightOffset + downOffset, Time.deltaTime * moveSpeed);
    }

    void CheckProximityPouring()
    {
        if (!hasLiquid || liquidAmount <= 0) return;

        float currentAngle = Vector3.Angle(transform.up, Vector3.up);
        if (currentAngle >= pourAngleThreshold)
        {
            TestTube[] targets = FindObjectsByType<TestTube>();
            foreach (TestTube targetTube in targets)
            {
                if (targetTube == this) continue;

                float distance = Vector3.Distance(transform.position, targetTube.transform.position);
                if (distance <= pourRadiusLimit)
                {
                    float frameTransfer = transferSpeed * Time.deltaTime;
                    if (frameTransfer > liquidAmount) frameTransfer = liquidAmount;

                    liquidAmount -= frameTransfer;
                    targetTube.ReceiveFluidStream(currentLiquidColor, frameTransfer);
                    break;
                }
            }
        }
    }

    public void ReceiveFluidStream(Color sourceColor, float incomingAmount)
    {
        if (!hasLiquid || liquidAmount <= 0)
        {
            hasLiquid = true;
            liquidAmount = 0f;
            currentLiquidColor = sourceColor;
        }
        else
        {
            currentLiquidColor = Color.Lerp(currentLiquidColor, sourceColor, 0.05f);
        }

        liquidAmount += incomingAmount;
        liquidAmount = Mathf.Clamp01(liquidAmount);
    }

    void UpdateVisualLiquid()
    {
        if (liquidInternalRenderer != null)
        {
            if (liquidAmount <= 0 || !hasLiquid)
            {
                liquidInternalRenderer.enabled = false;
                hasLiquid = false;
                return;
            }

            liquidInternalRenderer.enabled = true;
            liquidInternalRenderer.material.color = currentLiquidColor;

            Vector3 targetScale = initialLiquidScale;
            targetScale.y = initialLiquidScale.y * liquidAmount;
            liquidInternalRenderer.transform.localScale = targetScale;

            float heightDifference = initialLiquidScale.y * (1f - liquidAmount);
            Vector3 targetPos = liquidInternalRenderer.transform.localPosition;
            targetPos.y = initialLiquidYPos - heightDifference;
            liquidInternalRenderer.transform.localPosition = targetPos;
        }
    }
}
